
public class App {
    public static void main(String[] args) throws Exception {
        GUI ui = new GUI();
     
        ui.RenderBoard();
       
        

    }
}
