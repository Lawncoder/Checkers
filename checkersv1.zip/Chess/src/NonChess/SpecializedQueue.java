package NonChess;

import java.util.*;

public class SpecializedQueue<T> {
   int maxLength;
   ArrayList<T> values = new ArrayList<T>();
    public SpecializedQueue(int maxLength) {
        this.maxLength = maxLength;
        for (int i =0;i < maxLength; i++) {
            values.add(null);
        }
    }
    public void enqueue(T e) {
        values.add(e);
        if (values.size() > maxLength) {
            dequeue();
        }
    }
    public T dequeue() {
        T output = values.get(0);
        values.remove(0);
        return output;
    }
    public T get(int index) {
        return values.get(index);
    }
   

}