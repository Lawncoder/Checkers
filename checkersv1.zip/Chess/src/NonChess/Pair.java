package NonChess;

public class Pair<T,U> {
    public T first;
    public U second;
    public Pair(T first, U second) {
        this.first = first;
        this.second = second;
    }
    public Pair() {
 
    }
    
    @Override
    public boolean equals(Object obj) {
        
        if (!(obj instanceof Pair)) {
            return false;
        }
         Pair p = (Pair) obj;
        if (this.first.equals(p.first) && p.second.equals(this.second)) {
            return true;
        }else {
            return false;
        }
    }
    @Override
    public String toString() {
    
        String output = new String();
        output += "(";
        output += first.toString();
        output += ",";
        output += second.toString();
        output += ")";

        return output;
    }
}
