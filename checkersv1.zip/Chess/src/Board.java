
import java.util.ArrayList;
import java.util.Comparator;


import NonChess.Pair;

public class Board {
    Position currentPosition;
    boolean isGreenTurn;
    class MoveComparator implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            // TODO Auto-generated method stub
            StringBuilder a = new StringBuilder(o1);
            StringBuilder b = new StringBuilder(o2);
            if (a.charAt(4) != b.charAt(4)) {
                if (a.charAt(4) == '1') {
                    return 1;
                }else {
                    return -1;
                }
            }
            if (isGreenTurn) {
                return Integer.valueOf(o2) - Integer.valueOf(o1);
            }else {
                return Integer.valueOf(o1) - Integer.valueOf(o2);
            }

        }
    }
    public Board() {
        currentPosition = new Position();
        isGreenTurn = true;
    }
    public Board(Board copy) {
        currentPosition = new Position(copy.currentPosition);
        isGreenTurn = copy.isGreenTurn;
        
    }
    public void makeMove(Pair<Integer,Integer> current, Pair<Integer,Integer> target) {
        boolean captured = false;
        Pair<Boolean,Boolean> isMyMoveLegal = isMoveLegal(current, target);
        if (!isMyMoveLegal.first) {
            return;
        }
        if (isMyMoveLegal.second) {
            captured = true;
            Pair<Integer,Integer> pieceToRemove = getTargetSquare(current, target);
            
            currentPosition.board[pieceToRemove.first][pieceToRemove.second] = 0;
            currentPosition.board[target.first][target.second] = currentPosition.board[current.first][current.second];
            currentPosition.board[current.first][current.second] = 0;
            

        }else {
        
        currentPosition.board[target.first][target.second] = currentPosition.board[current.first][current.second];
        currentPosition.board[current.first][current.second] = 0;
        }
        if (target.first == 0) {
            currentPosition.board[target.first][target.second] = -2;
        }   
        if (target.first == 7) {
            currentPosition.board[target.first][target.second] = 2;
        }
     
          if (captured && canPieceCapture(target))  {
            return;
          }

          isGreenTurn = !isGreenTurn;
        
        
       
    } 
    public Pair<Boolean,Boolean> isMoveLegal(Pair<Integer,Integer> current, Pair<Integer,Integer> target) {
        Pair<Boolean,Boolean> output = new Pair<Boolean,Boolean>();
        output.first = false;
        output.second = false;
        int selectedPiece = currentPosition.board[current.first][current.second];
        if (current.equals(target)) {
            return output;
        }
        if (currentPosition.board[target.first][target.second] != 0) {
            return output;
        }
        if (isGreenTurn && selectedPiece > 0) {
            return output;
        }
        if (!isGreenTurn && selectedPiece < 0) {
            return output;
        }
        if (Math.abs(selectedPiece) == 1) {
        if (isGreenTurn) {
            if (!isGreenCaptureMove(current, target)) {
                if (!isDiaganolOneSpaceAbove(current, target)) {
                    return output;
                }
                if (selectedPiece != -1) {
                    return output;
                }
            }else {
                output.second = true;
                Pair<Integer,Integer> targetSquare = new Pair<Integer,Integer>(current.first - 1, (int)(Math.signum(target.second - current.second) + current.second));
                if (Math.signum(selectedPiece) == Math.signum(currentPosition.board[targetSquare.first][targetSquare.second])) {
                    return output;
                }
                if (currentPosition.board[targetSquare.first][targetSquare.second] == 0) {
                 
                    return output;

                }
            }
              
        }
        if (!isGreenTurn) {

            if(!isRedCaptureMove(current, target)) {
                if (!isDiaganolOneSpaceBelow(current, target)) { return output;} 
                if (selectedPiece != 1) {
               
                    return output;
                }
            }else {
                
                output.second = true;
                Pair<Integer,Integer> targetSquare = new Pair<Integer,Integer>(current.first + 1, (int)(Math.signum(target.second - current.second) + current.second));
                if (Math.signum(selectedPiece) == Math.signum(currentPosition.board[targetSquare.first][targetSquare.second])) {
                    return output;
                }
                if (currentPosition.board[targetSquare.first][targetSquare.second] == 0) {
                 
                    return output;

                }
            }

        }
    }else {
        //Is a king
        if (!isRedCaptureMove(current,target) && !isGreenCaptureMove(current, target)) {
            if (!isDiaganolOneSpaceAbove(current, target) && !isDiaganolOneSpaceBelow(current, target)) {
                return output;
            }
        }else {
            output.second = true;

           
            Pair<Integer,Integer> midpoint = new Pair<Integer,Integer>((current.first + target.first)/2, (current.second + target.second)/2);
         
            if (currentPosition.board[midpoint.first][midpoint.second] == 0) {
                return output;
            }
        }
        if (isGreenTurn) {
            if (selectedPiece > 0) {
                return output;
            }
        }else {
            if (selectedPiece < 0) {
                return output;
            }
        }
    }
        
        

        //On a success

        output.first = true;
        return output;
    
    }
    public Pair<Integer,Integer> getTargetSquare(Pair<Integer,Integer> current, Pair<Integer,Integer> target) {
        Pair<Integer,Integer> midpoint = new Pair<Integer,Integer>((current.first + target.first)/2, (current.second + target.second)/2);
        return midpoint;
    }
    public boolean isDiaganolOneSpaceAbove(Pair<Integer,Integer> current, Pair<Integer,Integer> target) {
       
    
        if (target.first - current.first == -1 && (Math.abs(current.second - target.second) == 1)) {
            return true;
        }else {
            return false;
         }
        
    }
    public boolean canPieceCapture(Pair<Integer,Integer> current) {
       
        int currentPiece = currentPosition.board[current.first][current.second];
        if (currentPiece == -1) {
            //Green Normal
            if (current.first > 1) {
                if (current.second < 6) {
                    if (isMoveLegal(current, new Pair<Integer,Integer>(current.first - 2, current.second + 2)).first) {
                        return true;
                    }
                }
                if (current.second > 1){
                    if (isMoveLegal(current, new Pair<Integer,Integer>(current.first - 2, current.second - 2)).first) {
                        return true;
                    }
                }
                return false;
                
            }else {
                return false;
            }
        
            
           
        }else if (currentPiece == 1) {
            //Red Normal
            if (current.first < 6) {
                if (current.second < 6) {
                    if (isMoveLegal(current, new Pair<Integer,Integer>(current.first + 2, current.second + 2)).first) {
                        return true;
                    }
                }
                if (current.second > 1){
                    if (isMoveLegal(current, new Pair<Integer,Integer>(current.first + 2, current.second - 2)).first) {
                        return true;
                    }
                }
                return false;
                
            }else {
                return false;
            }
        
        }
        else {
            //King
            if (current.first < 6) {
                if (current.second < 6) {
                    if (isMoveLegal(current, new Pair<Integer,Integer>(current.first + 2, current.second + 2)).first) {
                        return true;
                    }
                }
                if (current.second > 1){
                    if (isMoveLegal(current, new Pair<Integer,Integer>(current.first + 2, current.second - 2)).first) {
                        return true;
                    }
                }
               
                
            }
            if (current.first > 1) {
                if (current.second < 6) {
                    if (isMoveLegal(current, new Pair<Integer,Integer>(current.first - 2, current.second + 2)).first) {
                        return true;
                    }
                }
                if (current.second > 1){
                    if (isMoveLegal(current, new Pair<Integer,Integer>(current.first - 2, current.second - 2)).first) {
                        return true;
                    }
                }
                
                
            }
            return false;
        }


    }
    public boolean isDiaganolOneSpaceBelow(Pair<Integer,Integer> current, Pair<Integer,Integer> target) {
       
       

    
        if (target.first - current.first == 1 && (Math.abs(current.second - target.second) == 1)) {
            return true;
        }else {
            return false;
         }
        
    }
    public boolean isGreenCaptureMove(Pair<Integer,Integer> current, Pair<Integer,Integer> target) {
        if (Math.abs(current.second - target.second) == 2 && target.first - current.first == -2) {
            
            return true;
        }
        return false;
    }
    public boolean isRedCaptureMove(Pair<Integer,Integer> current, Pair<Integer,Integer> target) {
        if (Math.abs(current.second - target.second) == 2 && target.first - current.first == 2) {
            return true;
        }
        return false;
    }
    
    public ArrayList<String> getAllLegalMoves() {
        /*ArrayList<String> output = new ArrayList<String>();
        System.out.println("searching");
        for (int i = 0; i < 64; i++) {
            //Optimize j to only check squares in a 9 square square, and only if they are dark
            for (int j = 0; j< 64; j++) {
                if (currentPosition.board[i/8][i%8] != 0) {
                    Pair<Boolean,Boolean> moveLegal = isMoveLegal(new Pair<Integer,Integer>(i/8,i%8) ,new Pair<Integer,Integer>(j/8,j%8));
                    if (moveLegal.first) {
                        String concatter = "";
                        if (moveLegal.second) {
                            concatter = "1";
                        }else {
                            concatter = "0";
                        }

                        output.add(encodeMove(new Pair<Integer,Integer>(i/8,i%8),new Pair<Integer,Integer>(j/8,j%8)) + concatter);
                    }
                }
            }
            
        }
        
        
        
        output.sort(new MoveComparator());
        return output;*/

       
            ArrayList<String> output = new ArrayList<String>();
            System.out.println("searching");
            for (int i = 0; i < 64; i++) {
                //Optimize j to only check squares in a 9 square square, and only if they are dark
                for (int j = 0; j< 64; j++) {
                    if (currentPosition.board[i/8][i%8] != 0) {
                        Pair<Boolean,Boolean> moveLegal = isMoveLegal(new Pair<Integer,Integer>(i/8,i%8) ,new Pair<Integer,Integer>(j/8,j%8));
                        if (moveLegal.first) {
                            String concatter = "";
                            if (moveLegal.second) {
                                concatter = "1";
                            }else {
                                concatter = "0";
                            }
    
                            output.add(encodeMove(new Pair<Integer,Integer>(i/8,i%8),new Pair<Integer,Integer>(j/8,j%8)) + concatter);
                        }
                    }
                }
                
            }
            
            
            
            output.sort(new MoveComparator());
            return output;
        
    }
    public static String encodeMove(Pair<Integer,Integer> current, Pair<Integer,Integer> target) {
            String output = "";
            output += current.first;
            output += current.second;
            output += target.first;
            output += target.second;
            return output;
    }
    public static Pair<Pair<Integer,Integer>,Pair<Integer,Integer>> decodeMove(String encoded) {
        try {
        StringBuilder builder = new StringBuilder(encoded);
   
        Pair<Integer,Integer> current = new Pair<Integer,Integer>(Integer.valueOf(String.valueOf(builder.charAt(0))), Integer.valueOf(String.valueOf(builder.charAt(1))));
        Pair<Integer,Integer> target = new Pair<Integer,Integer>(Integer.valueOf(String.valueOf(builder.charAt(2))), Integer.valueOf(String.valueOf(builder.charAt(3))));
        return new Pair<Pair<Integer,Integer>,Pair<Integer,Integer>>(current,target);
        }
        catch (Exception ex) {
            System.out.println(encoded);
            ex.printStackTrace();
            return new Pair<Pair<Integer,Integer>,Pair<Integer,Integer>>();
        }

    }
    
    public static boolean isGameOver(Board board) {
        boolean hasGreen = false;
        boolean hasRed = false;
        for (int[] in : board.currentPosition.board) {
            for (int i : in) {
                if (i > 0) {
                    hasRed = true;
                }
                if (i < 0) {
                    hasGreen = true;
                }
            }

        }
        return !(hasGreen && hasRed);
    }
}

