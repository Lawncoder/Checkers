public class Position {
    public int[][] board;
    public static int[][] startingPosition = {
        {1 , 0 , 1, 0, 1 , 0 , 1 , 0},
        {0 , 1 , 0 , 1 , 0, 1, 0, 1},
        {1,0,1,0,1,0,1,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,-1,0,-1,0,-1,0,-1},
        {-1 , 0 , -1 , 0 , -1, 0, -1, 0},
        {0 , -1 , 0, -1, 0 , -1 , 0 , -1}
    };
    public static Position matrixToPosition(int[][] mat) {
        Position output = new Position();
        output.board = mat;
        return output;
    }
    public Position() {
        
    }
    public Position(Position copy) {
        board = new int[8][8];
        for (int i = 0; i < 64; i++) {
            board[i/8][i%8] = copy.board[i/8][i%8];
        }
    }
    
}
