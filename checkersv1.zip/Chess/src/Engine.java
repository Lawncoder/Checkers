import NonChess.*;
public class Engine {
   
    public static  double evaluatePosition(Board board) {
        double sum = 0;
        double scalingFactor = 0.05;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                sum += board.currentPosition.board[i][j];
                switch (board.currentPosition.board[i][j]) {
                    case 1:
                        sum += i * scalingFactor;
                        break;
                
                    case 2:
                        sum += scalingFactor * Math.abs(4-i);
                    break;

                    case -1:
                    sum -= (8-i) * scalingFactor;
                    break;
                    case -2: 
                    sum -= scalingFactor * Math.abs(4-i);
                    break;
                }
            }
        }
        return sum;
    }
    public static String findBestMove(Board currentBoard, int depth) {
        String bestMove = "0000";
        double maxEval = Double.NEGATIVE_INFINITY;
        for (String s : currentBoard.getAllLegalMoves()) {
           
            Pair<Pair<Integer,Integer>,Pair<Integer,Integer>> move = Board.decodeMove(s);
            Board temp = new Board(currentBoard);
            temp.makeMove(move.first, move.second);
            double eval = Engine.minimax(temp, depth, Double.NEGATIVE_INFINITY,Double.POSITIVE_INFINITY);
            if (eval > maxEval) {
                maxEval = eval;
                bestMove = s;
            }
            

        }
        System.out.println(maxEval);
        return bestMove;
    }
    public static double minimax(Board currentBoard, int depth, double alpha, double beta) {
        if (depth == 0 || Board.isGameOver(currentBoard) || currentBoard.getAllLegalMoves().size() == 0) {
            return evaluatePosition(currentBoard);
        }
        if (!currentBoard.isGreenTurn) {
            double maxEval = Double.NEGATIVE_INFINITY;
            for (String s : currentBoard.getAllLegalMoves()) {
                Pair<Pair<Integer,Integer>,Pair<Integer,Integer>> move = Board.decodeMove(s);
                Board temp = new Board(currentBoard);
                if (temp.equals(currentBoard)) {
                    System.err.println("Uh oh copying problem");
                }
                temp.makeMove(move.first, move.second);
                
                double eval = Engine.minimax(temp, depth - 1, alpha, beta);
                maxEval = Math.max(eval, maxEval);
                alpha = Math.max(alpha, eval);  // Update alpha
                if (beta <= alpha) {
                    break;  // Beta cutoff
                }
            }
            return maxEval;
        } else {
            double minEval = Double.POSITIVE_INFINITY;
            for (String s : currentBoard.getAllLegalMoves()) {
                Pair<Pair<Integer,Integer>,Pair<Integer,Integer>> move = Board.decodeMove(s);
                Board temp = new Board(currentBoard);
                temp.makeMove(move.first, move.second);
                double eval = Engine.minimax(temp, depth - 1, alpha, beta);
                minEval = Math.min(eval, minEval);
                beta = Math.min(beta, eval);  // Update beta
                if (beta <= alpha) {
                    break;  // Alpha cutoff
                }
            }
            return minEval;
        }
    }
}