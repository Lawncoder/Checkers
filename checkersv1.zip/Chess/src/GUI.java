import javax.swing.*;
import java.awt.event.*;
import NonChess.Pair;
import NonChess.SpecializedQueue;

import java.awt.*;

public class GUI {
    JFrame logFrame;
    JFrame frame = new JFrame();
    JPanel[][] squares = new JPanel[8][8];
    JButton[][] buttons = new JButton[8][8];
    JLabel[][] labels = new JLabel[8][8];
    Board board = new Board();
    SpecializedQueue<String> loggedMoves;
    JLabel[] display = new JLabel[8];

    Pair<Integer,Integer> selectedSquareOne;
    Pair<Integer,Integer> selectedSquareTwo;
   
    public GUI() {
        loggedMoves = new SpecializedQueue<String>(8);
        logFrame = new JFrame();
        logFrame.getContentPane().setLayout(new BoxLayout(logFrame.getContentPane(),BoxLayout.Y_AXIS));
        logFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        logFrame.setSize(200,800);
        logFrame.setVisible(true);
        for (int i = 0; i < 8; i++) {
            display[i] = new JLabel("Last Engine Move");
            logFrame.add(display[i]);
        }
        Timer ticker = new Timer(20, new Tick());
        ticker.start();
        board.currentPosition.board = Position.startingPosition;
        frame.setSize(640,650);
        frame.setLayout(new GridLayout(8,8));
   
        for (int i = 0;i<8;i++) {
            for (int j = 0; j < 8; j++) {
                Color currentColor;
                if (i%2 - j%2 != 0) {
                    currentColor = Color.DARK_GRAY;
                }else {
                    currentColor = Color.LIGHT_GRAY;
                }
                squares[i][j] = new JPanel();
                squares[i][j].setSize(80,80);
                squares[i][j].setBackground(currentColor);
                squares[i][j].setLayout(new BorderLayout());
                buttons[i][j] = new JButton();
                buttons[i][j].setOpaque(false);
                buttons[i][j].setBorderPainted(false);
                buttons[i][j].setContentAreaFilled(false);
                buttons[i][j].setSize(80,80);
                squares[i][j].add(buttons[i][j],BorderLayout.CENTER);
                labels[i][j] = new JLabel();
                labels[i][j].setText("(" + i + "," + j + ")");
                buttons[i][j].add(labels[i][j], BorderLayout.CENTER);
                frame.getContentPane().add(squares[i][j]);
                
                buttons[i][j].addActionListener(new ClickListener(i, j));
            }
        }
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    boolean isGreenTurn = true;
 
    public class ClickListener implements ActionListener {
        int row;
        int column;

        public ClickListener(int row, int column) {
            this.row = row;
            this.column = column;
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            if(board.isGreenTurn) {
            if (selectedSquareOne == null) {
                selectedSquareOne = new Pair<Integer,Integer>(row,column);
                if (board.currentPosition.board[selectedSquareOne.first][selectedSquareOne.second] == 0) {
                    selectedSquareOne = null;
                }
            }else {
                selectedSquareTwo = new Pair<Integer,Integer>(row,column);
                if (board.isMoveLegal(selectedSquareOne, selectedSquareTwo).first) {
              
                }
                board.makeMove(selectedSquareOne, selectedSquareTwo);
             
               
                

                selectedSquareOne = null;
                selectedSquareTwo = null;
                RenderBoard();
                
            }
        }

        }
    } 
    class Tick implements ActionListener {
       

        @Override
        public void actionPerformed(ActionEvent e) {
   
            if(!board.isGreenTurn) {
        
                     System.out.println("\033[H\033[2J");
                     System.out.flush(); 
           
                    String bestMove = Engine.findBestMove(board,3);
                   
                    Pair<Pair<Integer,Integer>,Pair<Integer,Integer>> move = Board.decodeMove(bestMove);
            
                    board.makeMove(move.first, move.second);
                    
                    loggedMoves.enqueue(move.toString());
                    for (int i = 0; i< 8; i++) {
                        display[i].setText(loggedMoves.get(i));
                    }

                    RenderBoard();
                }
            }
        }
    

    public void RenderBoard() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                Color currentColor;
                if (board.currentPosition.board[i][j] == 1) {
                    currentColor = Color.RED;
                }else if (board.currentPosition.board[i][j] == -1) {
                    currentColor = Color.GREEN;
                }else if (board.currentPosition.board[i][j] == 2) {
                    currentColor = new Color(100,0,0,255);

                }else if (board.currentPosition.board[i][j] == -2) {
                
                    currentColor = new Color(0,100,0,255);
                }
                else {
                    if (i%2 - j%2 != 0) {
                        currentColor = Color.DARK_GRAY;
                    }else {
                        currentColor = Color.LIGHT_GRAY;
                    }
                }
                squares[i][j].setBackground(currentColor);
            }
        }
        
    }
    
}
